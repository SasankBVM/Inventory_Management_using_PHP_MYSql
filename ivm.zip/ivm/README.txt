By default I'm using port 3307, as 3306 is not vacant in my local machine, if you wish to change go to "C:\xampp\htdocs\ivm\control\connection.php" and change.

After extracting the downloaded file, import the database present in the file "C:\xampp\htdocs\ivm\database\ivm.sql" in your respective database.

Finally go to this url after turning on Apache server and MySql in Xampp Control panel "http://localhost/ivm/view/login.php"

						***HAPPY CODING***

						   "THANK YOU"