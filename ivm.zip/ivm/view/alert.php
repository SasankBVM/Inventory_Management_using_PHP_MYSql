<?php
require '../redis/predis/src/Autoloader.php';
Predis\Autoloader::register();
$client = new Predis\Client([
    'scheme'=>'tcp', 
    'host'=>'127.0.0.1', 
    'port'=>6379, 
    ]); 
    $name=$_POST['uname'];
    $key = "cust_names:".$name.":cust_pwd";
    $pwd=$client->get($key);
    echo '<script>
    alert("PASSWORD IS"+pwd);
    </script>';
?>
