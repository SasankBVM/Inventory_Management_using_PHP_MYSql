<?php
require '../control/connection.php';
session_start();
error_reporting(E_ALL ^ E_WARNING); 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Include the necessary scripts and stylesheets -->
</head>
<body>
<style>
        .table_container {
            width: 80%;
            margin: 0 auto;
            padding: 40px;
        }
        .table-responsive {
            overflow-x: auto;
        }
        .table {
            width: 100%;
            margin-bottom: 0;
        }
        .thead-light th {
            background-color: #f8f9fa;
            color: #333;
            font-weight: bold;
        }
        .checkout {
            width: 100%;
            text-align: center;
            padding: 20px;
        }
        .checkout input[type="submit"] {
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 4px;
            font-size: 16px;
        }
        .selected-items {
            text-align: center;
            padding: 20px;
        }
        .total-amount {
            text-align: center;
            font-size: 24px;
            font-weight: bold;
        }
    </style>
    <!-- Display selected items table and total amount -->
    <div class="table_container">
    <div class="table-responsive">
            <table class="table table-dark" id="table" data-toggle="table" data-search="true" data-filter-control="true" data-show-export="true" data-click-to-select="true" data-toolbar="#toolbar">
                <thead class="thead-light">
                    <tr>
                        <th data-field="date" data-filter-control="select" data-sortable="true">S.NO</th>
                        <th data-field="note" data-filter-control="select" data-sortable="true">ITEM_NAME</th>
                        <th data-field="examen" data-filter-control="select" data-sortable="true">ITEM_PRICE</th>
                        <th data-field="note" data-sortable="true">ITEM_VENDOR</th>
                        <th data-field="purchase" data-sortable="false">QUANTITY SELECTED</th>
                        <th data-field="purchase" data-sortable="false">AMOUNT</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Retrieve the quantities from the session
                    $items = $_SESSION['last_item'];
                    $i = 1;
                    $totalAmount=0;
                    $dc=1;
                    $up_quan;
                    $item_name;
                    // Get the items from the database based on the selected quantities
                    $sql = "SELECT * FROM items";
                    $result = $res->query($sql);
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            $j=$i;
                            $vend_name = $row['item_vendor'];
                            $vendor_query = "SELECT `vendor_name` FROM `vendors` WHERE vendor_id='$vend_name'";
                            $vendor_result = $res->query($vendor_query);
                            $vendor_row = $vendor_result->fetch_assoc();

                            if ($_POST[$j]){
                                // Quantity for the item is greater than 0, add it to the selected items
                                echo "<tr>
                                        <td>" . $dc . "</td>
                                        <td>" . $row['item_name'] . "</td>
                                        <td>" . $row['item_price'] . "</td>
                                        <td>" . $vendor_row['vendor_name'] . "</td>
                                        <td>" . $_POST[$j] . "</td>
                                        <td>".$row['item_price']*$_POST[$j]."</td>
                                    </tr>";
                                    $dc++;
                                    $totalAmount += $row['item_price']*$_POST[$j];

                                $cust_name=$_SESSION["cust_name"];
                                $vendor=$row["item_vendor"];
                                $item_n=$row["item_name"];
                                $item_name=$item_n;
                                $quant=$_POST[$j];
                                $up_quan=$quant;
                                $amount=$row['item_price']*$_POST[$j];

                            $qry = "INSERT INTO `orders`(cust,vend,item,quantity,amount) VALUES ('$cust_name','$vendor','$item_n','$quant','$amount')";                            
                            $query=mysqli_query($res,$qry);
                            $rem="UPDATE `items` SET `item_quantity`=`item_quantity`-'$up_quan' WHERE `item_name`='$item_name'";
                            $ress=mysqli_query($res,$rem);
                            }
                            $i++;
                        }
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="selected-items">
        <h2>Total Amount: </h2>
        <h2 class="total-amount">
            <?php
            // Calculate the total bill amount
            echo "INR.". $totalAmount;
            ?>
        </h2>
    </div>

    <div class="checkout">
        <form action="" method="post">
            <!-- Include any additional fields or payment-related details here -->
            <input type="submit" value="Checkout" name="checkout">
        </form>
    </div>

    <?php 
    if (isset($_POST['checkout'])) {
        // // Insert data into the orders table
        // $cust = $_SESSION['customer'];
        // $vend = $_SESSION['vendor'];

        // $stmt = $res->prepare("INSERT INTO orders (cust, vend, item, quantity) VALUES (?, ?, ?, ?)");

        // foreach ($selectedItems as $item) {
        //     $stmt->bind_param("sssi", $cust, $vend, $item['item_name'], $item['item_quantity']);
        //     $stmt->execute();
        // }
        // $stmt->close();

        // Display the order confirmation alert
        $link_url="../view/cust_item.php";
        echo '<script>alert("Order placed successfully!");window.location="'.$link_url.'";</script>';

    }
    ?>

    <?php include('footer.php'); ?>
</body>
</html>
