<?php 
	require '../control/connection.php';
    $cust_name = $_POST['cust_name']; 
	$cust_cont = $_POST['cust_cont']; 
	$cust_email = $_POST['cust_email'];
    $cust_pwd=$_POST['password'];
    $cust_rpwd=$_POST['rpwd'];
	$cust_name=strtoupper($cust_name);
        if($cust_pwd!=$cust_rpwd)
        {
            echo '<html>  
		    <head> 
				<style> 
					body{ 
					background-color:yellow; 
					 
					padding:200px; 
					}
				</style>
			</head>
            <body><h1>PASSWORDS DID NOT MATCH </h1></body>
            <br>
            <a href="cust_register.php">CLICK HERE TO RE-REGISTER></a>
		</html>';
        }
        else{
    $qry="insert into `customers`(cust_cont,cust_name,password,cust_email) values ('$cust_cont','$cust_name','$cust_pwd','$cust_email')";
	//$client->rpush("passengers",$aadhar);  
    //$client->sAdd("cust_names",$cust_name,1);   
	$query=mysqli_query($res,$qry);
	if($query)
	{
	echo ' <script> 
	    alert(" Congrats !! YOU HAVE GOT REGISTERED SUCCESFULLY") ; 
    </script>';	
    // echo "Connection to server sucessfully"; 
   //check whether server is running or not 
   echo '
			<style>
			h1 {
				width:500px;
				margin: 0 auto;
				background: cyan;
				text-color:red;
				text-align: center;
			}
			</style>
   		<html>  
		    <head> 
				<style> 
					body{ 
					background-color:yellow; 
					 
					padding:200px; 
					}
				</style>
			</head>
		</html>' ;
   echo "<h1> Dear ".$cust_name." YOUR ID IS ".$cust_cont ." </h1>";
   echo "<br>"; 
   echo '<a href="../view/login.php"> <p style="text-align: center;">CLICK HERE TO LOGIN</p> </a> ';
			}
			else{
				echo ' <script> alert(" OOPS SOMETHING WENT WRONG"); </script> ';
			}
		}   
?>