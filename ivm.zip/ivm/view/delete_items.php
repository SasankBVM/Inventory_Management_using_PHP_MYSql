<!DOCTYPE html>
<html>

<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta charset="utf-8">
  <title>Inventory Management</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <style>
    body {
      font-family: Calibri, Helvetica, sans-serif;
      background-color: #FCE4EC;
    }

    .container {
      padding: 30px;
      background-color: #FFF3E0;
      border-radius: 10px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
      max-width: 500px;
      margin: auto;
    }

    .form-group {
      margin-bottom: 25px;
    }

    label {
      font-size: 16px;
      font-weight: bold;
    }

    input[type=text],
    input[type=password],
    input[type=number],
    textarea {
      width: 100%;
      padding: 10px;
      margin: 5px 0 15px 0;
      display: inline-block;
      border: none;
      border-radius: 3px;
      background-color: #F5F5F5;
    }

    input[type=text]:focus,
    input[type=password]:focus,
    input[type=number]:focus,
    textarea:focus {
      background-color: #FFF9C4;
      outline: none;
    }

    button[type=submit] {
      background-color: #FF4081;
      color: white;
      padding: 10px 15px;
      margin: 10px 0;
      border: none;
      border-radius: 3px;
      cursor: pointer;
      transition: background-color 0.3s;
    }

    button[type=submit]:hover {
      background-color: #E91E63;
    }

    .navbar {
      margin-bottom: 0;
      background-color: #FF4081;
      border: none;
      border-radius: 0;
    }

    .navbar-inverse .navbar-nav>li>a {
      color: #FFFFFF;
      font-size: 16px;
      font-weight: bold;
    }

    .navbar-inverse .navbar-nav>li.active>a {
      background-color: #E91E63;
    }

    hr {
      border: none;
      border-top: 1px solid #F5F5F5;
      margin: 25px 0;
    }

    h1 {
      font-size: 28px;
      font-weight: bold;
      color: #FF4081;
    }
  </style>
</head>

<body>
  <nav class="navbar navbar-inverse">
    <div class="container-fluid">
      <div class="navbar-header">
        <a class="navbar-brand" href="#">Inventory Management</a>
      </div>
      <ul class="nav navbar-nav">
        <li><a href="../view/vendor_home.html">HOME</a></li>
        <li><a href="../view/add_item.php">ADD ITEM</a></li>
        <li class="active"><a href="#">DELETE ITEM</a></li>
        <li><a href="../view/item_view.php">VIEW YOUR ITEMS</a></li>
        <li><a href="../view/view_orders.php">VIEW ORDERS</a></li>
        <li><a href="../view/vendor_login.php">LOG OUT</a></li>
      </ul>
    </div>
  </nav>
  <div class="container">
    <h1 style="text-align: center;">DELETE ITEM</h1>
    <hr>
    <form action="../view/item_del.php" method="POST">
      <!-- <div class="header">
        <h1>Inventory Management</h1>
        <nav>
          <ul>
            <li><a href="#">Home</a></li>
            <li class="active"><a href="#">Add Item</a></li>
            <li><a href="../view/view_items.php">View Your Items</a></li>
            <li><a href="../view/vendor_login.php">Log Out</a></li>
          </ul>
        </nav>
      </div> -->

      <div class="content">
        <!-- <h2>Add Item</h2> -->
        <div class="form-group">
          <label for="item_name">Item Name:</label>
          <input type="text" class="form-control" id="item_name" name="item_name" placeholder="Enter item name" required>
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
      </div>
    </form>
  </div>
  </body>