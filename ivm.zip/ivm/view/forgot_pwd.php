<style>
  *{
 margin: 20;
 text-align: center;
 padding: 0px;
}
label {
    display: block;
    font: .9rem 'Fira Sans', sans-serif;
}

input[type='submit'],
label {
    margin-top: 1rem;
}
html{
    width: 100vw;
    height: 100vh;
}

/* CSS which you need for blurred box */
body{
 background-repeat: no-repeat;
 background-attachment: fixed;
 background-size: cover;
 background-position: top;
 background-image:url(http://bit.ly/2gPLxZ4);
 width: 100%;
 height: 100%;
 font-family: Arial, Helvetica;
 letter-spacing: 0.02em;
  font-weight: 400;
 -webkit-font-smoothing: antialiased; 
 align-items: center;
}

.blurred-box{
  position: relative;
  width: 250px;
  height: 350px;
  top: calc(50% - 175px);
  left: calc(50% - 125px);
  background: inherit;
  border-radius: 2px;
  overflow: hidden;
}
#popUpYes
{
  width: 60px;
  height: 30px;
  background-color: cyan;
}
#popUpYes:hover
{
  background-color: green;
}
.blurred-box:after{
 content: '';
 width: 300px;
 height: 300px;
 background: inherit; 
 position: absolute;
 left: -25px;
 left: position;
 right: 0;
 top: -25px;  
 top: position ;
 bottom: 0;
 box-shadow: inset 0 0 0 200px rgba(255,255,255,0.05);
 filter: blur(10px);
}
.fgt{
  align-items: center;
}
/* Form which you dont need */
.user-login-box{
  position: relative;
  margin-top: 50px;
  text-align: center;
  z-index: 1;
}
.user-login-box > *{
  display: inline-block;
  width: 200px;
}

.user-icon{
  width: 100px;
  height: 100px;
  position: relative;
  border-radius: 50%;
  background-size: contain;
  background-image: url(https://pbs.twimg.com/profile_images/725321660484583424/ArQ4fM3k.jpg);
}

.user-name{
  margin-top: 15px;
  margin-bottom: 15px;
  color: white;
}

input.user-password{
  width: 120px;
  height: 18px;
  opacity: 0.4;
  border-radius: 2px;
  padding: 5px 15px;
  border: 0;
}
</style>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="../redis/alert.php" method="POST" name="fgt">
      <div class="userbox">
    <label for="uname" style="text-align: center;color: red"><b><big>USERID</big></b></label>
      <input style="text-align: center; align-content: center;" type="text" placeholder="Enter USER ID" id="uname" name="uname" required>
      </div>
      <br>
      <br>
      <div>
      <label style="color: gold;" for="username"><b>USERNAME</b></label>
      <input type="text" placeholder="Enter USERNAME" name="uname" required>
      <br>
      <input type="submit" value="SUBMIT" id="popUpYes">
      </div>
    </form>
</body>
</html>