<?php
require '../control/connection.php'
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta name="viewport" content="width=device-width, initial-scale=10">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="../css/product.css">
    <link rel="stylesheet" type="text/css" href="../css/navigation.css">
    <title>ITEMS</title>
</head>

<body>
    <?php
    echo '
    <nav class="navbar navbar-inverse">
        <div class="container-fluid">
          <ul class="nav navbar-nav">
            <!-- <li class="active"><a href="#">Home</a></li> -->
            <li><a class="navbar-brand" href="#">INVENTORY MANAGEMENT</a></li>
            <li><a href="customer_reg.php">CUSTOMER_REGISTRATION</a></li>
            <li><a href="vendor_registration.php">VENDOR_REGSITRATION</a></li>
            <li class="active"><a href="#">ITEM SEARCH</a></li>
            <!-- <li><a href="purchase.php">PURCHASE ITEM</a></li> -->
            <li><a href="login.php">CUSTOMER_LOGIN</a></li>
            <li><a href="vendor_login.php">VENDOR_LOGIN</a></li>
            <li><a href="../view/vendor_details.php">VENDOR DETAILS</a></li>
            <!-- <li><a href="#">LOG OUT</a></li> -->
          </ul>
        </div>
      </nav>
    <h1 style="text-align: center;color: darkorange;">ITEMS AVAILABLE</h1>
    <div class="row" style="padding: 40px;">
        <div class="leftcolumn">';
    ?>
    <?php
    echo '<div class="card">
                <div class="table_container">
                    <div class="table-responsive">
                        <table class="table table-dark" id="table" data-toggle="table" data-search="true" data-filter-control="true" data-show-export="true" data-click-to-select="true" data-toolbar="#toolbar">
                            <thead class="thead-light">
                                <tr>
                                    <th data-field="date" data-filter-control="select" data-sortable="true">S.NO</th>
                                    <th data-field="note" data-filter-control="select" data-sortable="true">ITEM_NAME</th>
                                    <th data-field="examen" data-filter-control="select" data-sortable="true">ITEM_QUANTITY</th>
                                    <th data-field="note" data-sortable="true">ITEM_VENDOR</th>
                                </tr>
                            </thead>
                            <tbody>';
    $sql = "SELECT * FROM items";
    $result = $res->query($sql);
    if ($result->num_rows > 0) {
        $i=1;
        while ($row = $result->fetch_assoc()) {
          $vend_name=$row['item_vendor'];
          $test="SELECT `vendor_name` from `vendors` where vendor_id='$vend_name'";
          $test_r=$res->query($test);
          while($col=$test_r->fetch_assoc())
          if($row["item_quantity"]>0)
          {
          // $test_r_=$test_r->fetch_assoc();
            echo "<tr><td>" . $i++ . "</td><td>" . $row["item_name"] . "</td><td>" . $row["item_quantity"] . "</td><td>" . $col['vendor_name'] . "</td></tr>";
        }
    }
    }
    echo '
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>';
    ?>
    </div>
    <?php include('footer.php') ?>
</body>

</html>