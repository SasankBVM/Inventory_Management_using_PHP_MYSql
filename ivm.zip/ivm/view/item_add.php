<?php
require '../control/connection.php';
session_start();
$item_name=$_POST['item_name'];
$item_quan=$_POST['item_quantity'];
$item_price=$_POST['item_price'];
$vend_id=$_SESSION["vendor_id"];
// CHECKING VENDOR IS AUTH
$test = "select * from `vendors` where vendor_id = '$vend_id'";
$test_r=mysqli_query($res,$test);
if(mysqli_num_rows($test_r)>0)
{
// CHECKING ITEM ALREADY EXISTS OR NOT
$item_name=strtoupper($item_name);
$test_name="select * from `items` where item_name='$item_name'";
$result = $res->query($test_name);
    if ($result->num_rows > 0) {
       $row = $result->fetch_assoc();
       $up_quan=$row['item_quantity']+$item_quan;
    $up_qr="UPDATE `items` SET `item_quantity`='$up_quan' WHERE item_name='$item_name' AND item_vendor='$vend_id'";
    $temp=$res->query($up_qr);
    echo '<script>alert("'."ITEM ALREADY EXISTS. QUANTITY UPDATED".'"); window.location="'."../view/view_items.php".'";</script>';
    }
    else{
$item_name=strtoupper($item_name);
$qry="insert into `items`(item_name,item_quantity,item_vendor,item_price) values('$item_name','$item_quan','$vend_id','$item_price')";
$query=mysqli_query($res,$qry);
if($query)
	{
    echo '<script>alert("'."ITEM ADDED SUCCESSFULLY".'"); window.location="'."../view/item_view.php".'";</script>';
    exit();
    }
}
}
else{
$link_text="YOU ARE NOT AN AUTHORIZED VENDOR. CLICK ME";
$link_url="../view/add_item.php";
echo '<script>alert("'.$link_text.'"); window.location="'.$link_url.'";</script>';
}
