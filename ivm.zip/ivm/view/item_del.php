<?php
require '../control/connection.php';
$item_name = $_POST['item_name'];
session_start();
// CHECKING VENDOR IS AUTH
$vend_id=$_SESSION["vendor_id"];
$test = "select * from `vendors` where vendor_id='$vend_id'";
$test_r = mysqli_query($res, $test);
if (mysqli_num_rows($test_r) > 0) {
    // CHECKING ITEM ALREADY EXISTS OR NOT
    $item_name = strtoupper($item_name);
    $test_name = "select * from `items` where item_name='$item_name'";
    $result = $res->query($test_name);
    if ($result->num_rows > 0) {
        $up_qr = "DELETE FROM `items` WHERE item_name='$item_name'";
        $temp = $res->query($up_qr);
        echo '<script>alert("' . "ITEM DELETED SUCCESSFULLY!!" . '"); window.location="' . "../view/view_items.php" . '";</script>';
    } else {
        echo '<script>alert("' . "ITEM NOT FOUND" . '"); window.location="' . "../view/delete_items.php" . '";</script>';
        exit();
    }
} else {
    $link_text = "YOU ARE NOT AN AUTHORIZED VENDOR. CLICK ME";
    $link_url = "../view/add_item.php";
    echo '<script>alert("' . $link_text . '"); window.location="' . $link_url . '";</script>';
}
