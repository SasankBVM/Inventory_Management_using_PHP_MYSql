<?php
require '../control/connection.php';
session_start();
$vend_id = $_SESSION["vendor_id"];
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=10">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <style>
        body {
            font-family: Calibri, Helvetica, sans-serif;
            background-color: #FCE4EC;
        }

        .container {
            padding: 30px;
            background-color: #FFF3E0;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
            max-width: 500px;
            margin: auto;
        }

        .form-group {
            margin-bottom: 25px;
        }

        label {
            font-size: 16px;
            font-weight: bold;
        }

        input[type=text],
        input[type=password],
        input[type=number],
        textarea {
            width: 100%;
            padding: 10px;
            margin: 5px 0 15px 0;
            display: inline-block;
            border: none;
            border-radius: 3px;
            background-color: #F5F5F5;
        }

        input[type=text]:focus,
        input[type=password]:focus,
        input[type=number]:focus,
        textarea:focus {
            background-color: #FFF9C4;
            outline: none;
        }

        button[type=submit] {
            background-color: #FF4081;
            color: white;
            padding: 10px 15px;
            margin: 10px 0;
            border: none;
            border-radius: 3px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        button[type=submit]:hover {
            background-color: #E91E63;
        }

        .navbar {
            margin-bottom: 0;
            background-color: #FF4081;
            border: none;
            border-radius: 0;
        }

        .navbar-inverse .navbar-nav>li>a {
            color: #FFFFFF;
            font-size: 16px;
            font-weight: bold;
        }

        .navbar-inverse .navbar-nav>li.active>a {
            background-color: #E91E63;
        }

        hr {
            border: none;
            border-top: 1px solid #F5F5F5;
            margin: 25px 0;
        }

        h1 {
            font-size: 28px;
            font-weight: bold;
            color: #FF4081;
        }
    </style>
    <!-- jQuery library -->
    

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="../css/product.css">
    <link rel="stylesheet" type="text/css" href="../css/navigation.css">
    <title>ORDERS</title>
</head>

<body>
    <?php
    echo '
    <nav class="navbar navbar-inverse">
    <div class="container-fluid">
      <div class="navbar-header">
        <a class="navbar-brand" href="#">Inventory Management</a>
      </div>
      <ul class="nav navbar-nav">
        <li><a href="#">HOME</a></li>
        <li><a href="../view/add_item.php">ADD ITEM</a></li>
        <li><a href="../view/delete_items.php">DELETE ITEM</a></li>
        <li><a href="../view/view_items.php">VIEW YOUR ITEMS</a></li>
        <li class="active"><a href="#">VIEW ORDERS</a></li>
        <li><a href="../view/vendor_login.php">LOG OUT</a></li>
      </ul>
    </div>
  </nav>
    <h1 style="text-align: center;color: darkorange;">YOUR ORDERS</h1>
    <div class="row" style="padding: 40px;">
        <div class="leftcolumn">';
    // CHECKING VENDOR IS AUTH
    $test = "select password from `vendors` where vendor_id='$vend_id'";
    $test_r = $res->query($test);
    if (mysqli_num_rows($test_r) > 0) {
        // CHECKING ITEM ALREADY EXISTS OR NOT
        $psw=$test_r->fetch_assoc();
        $test_name = "select * from `orders` where vend='$vend_id'";
        $result = $res->query($test_name);
        // if ($result->num_rows > 0) {
        echo '<div class="card">
        <div class="table_container">
            <div class="table-responsive">
                <table class="table table-dark" id="table" data-toggle="table" data-search="true" data-filter-control="true" data-show-export="true" data-click-to-select="true" data-toolbar="#toolbar">
                    <thead class="thead-light">
                        <tr>
                           <th data-field="date" data-filter-control="select" data-sortable="true">S.NO</th>
                           <th data-field="date" data-filter-control="select" data-sortable="true">ORDER_ID</th>
                           <th data-field="note" data-filter-control="select" data-sortable="true">ITEM_NAME</th>
                           <th data-field="examen" data-filter-control="select" data-sortable="true">ITEM_QUANTITY</th>
                           <th data-field="examen" data-filter-control="select" data-sortable="true">BILL AMOUNT(₹)</th>
                           </tr>
                           </thead>
                           <tbody>';
        $i = 1;
        while ($row = $result->fetch_assoc()) {
            $item = $row['item'];
            $price_qr = "select `item_price` from `items` WHERE `item_name`='$item'";
            $price = $res->query($price_qr);
            $price = $price->fetch_assoc();
            echo '<tr><td>' . $i++ . '</td><td>' . $row['order_id'] . '</td><td>' . $row['item'] . '</td><td>' . $row['quantity'] . '</td><td>' . $price . '</td></tr>';
        }
        echo '
                            </tbody>
                        </table>
                    </div>
                </div>';
        // }
    
 }
 else {
        $link_text = "YOU ARE NOT AN AUTHORIZED VENDOR. CLICK ME";
        $link_url = "../view/vendor_registration.php";
        echo '<script>alert("' . $link_text . '"); window.location="' . $link_url . '";</script>';
    } ?>
    <?php include('footer.php') ?>
</body>

</html>