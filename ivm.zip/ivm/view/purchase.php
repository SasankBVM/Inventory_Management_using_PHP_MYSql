<?php
require '../control/connection.php';
?>

<!DOCTYPE html>
<html lang="en">
<style>
    .center-box {
        width: 200px;
        margin: 0 auto;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .input-field {
        width: 150px;
        padding: 10px;
        border: 1px solid #ccc;
        border-radius: 4px;
    }
</style>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=10">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="../css/product.css">
    <link rel="stylesheet" type="text/css" href="../css/navigation.css">
    <title>PURCHASE ITEM</title>
</head>

<body>
    <?php
    session_start();
    echo '
    <nav class="navbar navbar-inverse">
        <div class="container-fluid">
            <ul class="nav navbar-nav">
                <li><a href="#">HOME</a></li>
                <li><a href="./cust_item.php">ITEM SEARCH</a></li>
                <li><a href="../view/vendor_details_cust.php">VENDOR DETAILS</a></li>
                <li class="active"><a href="#">PURCHASE ITEM</a></li>
                <li><a href="../view/login.php">LOG OUT</a></li>
            </ul>
        </div>
    </nav>
    <h1 style="text-align: center;color: darkorange;">PURCHASE ITEM</h1>
    <div class="row" style="padding: 40px;">
        <div class="leftcolumn">
            <form method="POST" action="checkout.php">
                <div class="card">
                    <div class="table_container">
                        <div class="table-responsive">
                            <table class="table table-dark" id="table" data-toggle="table" data-search="true" data-filter-control="true" data-show-export="true" data-click-to-select="true" data-toolbar="#toolbar">
                                <thead class="thead-light">
                                    <tr>
                                        <th data-field="date" data-filter-control="select" data-sortable="true">S.NO</th>
                                        <th data-field="note" data-filter-control="select" data-sortable="true">ITEM_NAME</th>
                                        <th data-field="examen" data-filter-control="select" data-sortable="true">ITEM_QUANTITY AVAILABLE</th>
                                        <th data-field="note" data-sortable="true">ITEM_VENDOR</th>
                                        <th data-field="purchase" data-sortable="false">QUANTITY</th>
                                    </tr>
                                </thead>
                                <tbody>';
    $sql = "SELECT * FROM items";
    $result = $res->query($sql);
    if ($result->num_rows > 0) {
        $i = 1;
        while ($row = $result->fetch_assoc() and $i<=$result->num_rows) {
            $vend_name = $row['item_vendor'];
            $vendor_query = "SELECT `vendor_name` FROM `vendors` WHERE vendor_id='$vend_name'";
            $vendor_result = $res->query($vendor_query);
            $vendor_row = $vendor_result->fetch_assoc();
            if($row["item_quantity"]>0)
          {
            echo "<tr>
                    <td>" . $i. "</td>
                    <td>" . $row["item_name"] . "</td>
                    <td>" . $row["item_quantity"] . "</td>
                    <td>" . $vendor_row['vendor_name'] . "</td>
                    <td><input type='number' name='{$i}' min='0' max={$row['item_quantity']} '" . $row['item_quantity'] . "' value='0'></td>
                </tr>";
                $i=$i+1;
        }
    }
        $_SESSION['last_item']=$i;
    }
    echo '
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="checkout center-box">
                    <input type="submit" value="Checkout" style="padding: 10px 20px; background-color: #4CAF50; color: white; border: none; cursor: pointer; border-radius: 4px; font-size: 16px;">
                </div>
            </form>
        </div>
    </div>';
    ?>

    <?php include('footer.php') ?>
</body>

</html>
