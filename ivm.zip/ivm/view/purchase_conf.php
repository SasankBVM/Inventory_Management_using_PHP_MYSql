<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <script>
        alert("HORRAY!! YOUR ORDER PLACED SUCCESFULLY");
    </script>
    <h1 style="text-align: center; color: navy; background-color: blanchedalmond;"><a href="../view/login.php">CLICK HERE TO QUIT</a></h1>
</body>
</html>