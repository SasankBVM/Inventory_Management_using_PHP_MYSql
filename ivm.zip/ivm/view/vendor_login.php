<?php
session_start();
session_unset();
session_destroy();
?>
<style>
    form {
  border: 3px solid #f1f1f1;
}
/* Full-width inputs */
input[type=text], input[type=password] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}

/* Set a style for all buttons */
button {
  background-color: cyan;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
}

/* Add a hover effect for buttons */
button:hover {
  opacity: 0.8;
}

/* Extra style for the cancel button (red) */
.cancelbtn {
  text-align: center;
  width: auto;
  margin-left: 520px;
  padding: 10px 18px;
  background-color: burlywood;
}
/* Center the avatar image inside this container */
.imgcontainer {
  text-align: center;
  height: 1px;
  width: 20px;
}

/* Avatar image */
img.avatar {
  width: 20%;
  border-radius: 50%;
}

/* Add padding to containers */
.container {
  padding: 16px;
}

/* The "Forgot password" text */
span.psw {
  float: right;
  padding-top: 16px;
}
.imgcontainer {
  background-image: url("img2.png");
  /* background-size: cover; */
  border-radius: 30%;
  width: 5px;
  height: 1px;
  margin-left: 100px;
  margin-right: 5px;
  padding-left: 20px;
  padding-right: 20px;
  border: solid 5px red;
}
/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
  span.psw {
    display: block;
    float: none;
  }
  .cancelbtn {
    width: 100%;
  }
}
.btn {
  border: none;
  outline: none;
  padding: 10px 16px;
  background-color: #f1f1f1;
  cursor: pointer;
}

/* Style the active class (and buttons on mouse-over) */
.active, .btn:hover {
  background-color:darkmagenta;
  color: white;
}
</style>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Inventory Managgement</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
    <a class="navbar-brand" href="#"><p style="text-align: center;">INVENTORY MANAGEMENT</p></a>
    </div>
    <ul class="nav navbar-nav">
      <!-- <li class="active"><a href="#">Home</a></li> -->
      <li><a href="customer_reg.php">CUSTOMER_REGISTRATION</a></li>
      <li><a href="vendor_registration.php">VENDOR_REGSITRATION</a></li>
      <li><a href="item.php">ITEM SEARCH</a></li>
      <!-- <li><a href="purchase.php">PURCHASE ITEM</a></li> -->
      <li><a href="login.php">CUSTOMER_LOGIN</a></li>
      <li class="active"><a href="vendor_login.php">VENDOR_LOGIN</a></li>
      <li><a href="vendor_details.php">VENDOR DETAILS</a></li>
      <!-- <li><a href="#">LOG OUT</a></li> -->
    </ul>
  </div>
</nav>
<h1 style="text-align: center; color: darkgoldenrod;">VENDOR LOGIN</h1>
<form action="../view/vendor_page.php" method="post">
      <p align="center"><img src="img2.png" alt="Avatar" class="avatar"></p>
    <div class="container">
      <label for="uname"><b>VENDOR ID</b></label>
      <input type="text" placeholder="Enter Username" name="vname" required>
  
      <label for="psw"><b>PASSWORD</b></label>
      <input type="password" placeholder="Enter Password" name="psw" required>
      <button type="submit">LOGIN</button>
      <!-- <label>
        <input type="checkbox" checked="checked" name="remember"> Remember me
      </label> -->
    </div>
  <!-- <div class="../redis/forgot_pwd.php" method=POST >
    <a style="text-align: center;" href="../redis/forgot_pwd.php"><p style="text-align: center;">FORGOT PASSWORD</p></a></span>
  </div> -->
    <div class="container" style="background-color:#f1f1f1">
      <button type="button" class="cancelbtn"><a href="login.php">Cancel</a></button>
      <h5 style="text-align: center; border-right: 10px;">Don't have an account yet?</h5>
      <a style="text-align: center;" href="vendor_registration.php"><p style="text-align: center;">CLICK HERE TO REGISTER</p></a></span>
    </div>
    <?php  require 'footer.php'?>
  </form>
</body>
</html>