<!DOCTYPE html>
<html>

<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    body {
      font-family: Calibri, Helvetica, sans-serif;
      background-color: pink;
    }

    .container {
      padding: 50px;
      background-color: lightblue;
    }

    input[type=text],
    input[type=password],
    textarea {
      width: 100%;
      padding: 15px;
      margin: 5px 0 22px 0;
      display: inline-block;
      border: none;
      background: #f1f1f1;
    }

    input[type=text]:focus,
    input[type=password]:focus {
      background-color: cyan;
      outline: none;
    }

    div {
      padding: 10px 0;
    }

    hr {
      border: 1px solid #f1f1f1;
      margin-bottom: 25px;
    }

    .registerbtn {
      background-color: #4CAF50;
      color: white;
      padding: 16px 20px;
      margin: 8px 0;
      border: none;
      cursor: pointer;
      width: 100%;
      opacity: 1;
    }

    .registerbtn:hover {
      opacity: 1;
    }
  </style>
  <title>Inventory Managgement</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>

<body>
  <form action="../view/vendor_reg.php" method="POST">
    <nav class="navbar navbar-inverse">
      <div class="container-fluid">
        <ul class="nav navbar-nav">
          <!-- <li class="active"><a href="#">Home</a></li> -->
          <li><a class="navbar-brand" href="#">INVENTORY MANAGEMENT</a></li>
          <li><a href="customer_reg.php">CUSTOMER_REGISTRATION</a></li>
          <li class="active"><a href="#">VENDOR_REGSITRATION</a></li>
          <li><a href="item.php">ITEM SEARCH</a></li>
          <!-- <li><a href="purchase.php">PURCHASE ITEM</a></li> -->
          <li><a href="login.php">CUSTOMER_LOGIN</a></li>
          <li><a href="vendor_login.php">VENDOR_LOGIN</a></li>
          <li><a href="vendor_details.php">VENDOR DETAILS</a></li>
          <!-- <li><a href="#">LOG OUT</a></li> -->
        </ul>
      </div>
    </nav>
    <div class="container">
      <center>
        <h1>VENDOR REGSITRATION</h1>
      </center>
      <hr>
      <label> Firstname </label>
      <input type="text" name="firstname" placeholder="Firstname" id="firstname" size="15" required />
      <label> Lastname: </label>
      <input type="text" name="lastname" placeholder="Lastname" id="lastname" size="15" required />
      <div>
        <label>
          Gender :
        </label><br>
        <input type="radio" value="Male" name="gender" id="gender" checked> Male
        <input type="radio" value="Female" name="gender" id="gender"> Female
        <!-- <input type="radio" value="Other" name="gender"> Other   -->
      </div>
      <label>
        Phone :
      </label>
      <input type="text" name="vend_contact" placeholder="Contact" id="vend_contact" size="10" />
      <!-- <input type="text" name="phone" placeholder="phone no." size="10"/ required>    -->
      Current Address :
      <textarea cols="80" name="vend_address" rows="5" placeholder="Current Address" value="vend_address" id="vend_address" required>
</textarea>
      <label for="email"><b>Email</b></label>
      <input type="text" placeholder="Enter Email" name="vend_email" id="vend_email" required>

      <label for="psw"><b>Password</b></label>
      <input type="password" placeholder="Enter Password" name="vend_pwd" id="vend_pwd" required>

      <label for="psw-repeat"><b>Re-type Password</b></label>
      <input type="password" placeholder="Retype Password" name="vend_rpwd" id="vend_rpwd" required>
      <button type="submit" class="registerbtn">REGISTER</button>
      <h3 style="text-align: center; border-right: 10px;">ALREADY HAD AN ACCOUNT? </h3>
      <a style="text-align: center;" href="../view/vendor_login.php">
        <p style="text-align: center;">SIGN IN</p>
      </a></span>
  </form>
</body>

</html>