<?php
require '../control/connection.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta charset="utf-8">
  <title>Inventory Management</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <style>
    body {
      font-family: Calibri, Helvetica, sans-serif;
      background-color: #FCE4EC;
    }

    .container {
      padding: 30px;
      background-color: #FFF3E0;
      border-radius: 10px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
      max-width: 500px;
      margin: auto;
    }

    .form-group {
      margin-bottom: 25px;
    }

    label {
      font-size: 16px;
      font-weight: bold;
    }

    input[type=text],
    input[type=password],
    input[type=number],
    textarea {
      width: 100%;
      padding: 10px;
      margin: 5px 0 15px 0;
      display: inline-block;
      border: none;
      border-radius: 3px;
      background-color: #F5F5F5;
    }

    input[type=text]:focus,
    input[type=password]:focus,
    input[type=number]:focus,
    textarea:focus {
      background-color: #FFF9C4;
      outline: none;
    }

    button[type=submit] {
      background-color: #FF4081;
      color: white;
      padding: 10px 15px;
      margin: 10px 0;
      border: none;
      border-radius: 3px;
      cursor: pointer;
      transition: background-color 0.3s;
    }

    button[type=submit]:hover {
      background-color: #E91E63;
    }

    .navbar {
      margin-bottom: 0;
      background-color: #FF4081;
      border: none;
      border-radius: 0;
    }

    .navbar-inverse .navbar-nav>li>a {
      color: #FFFFFF;
      font-size: 16px;
      font-weight: bold;
    }

    .navbar-inverse .navbar-nav>li.active>a {
      background-color: #E91E63;
    }

    hr {
      border: none;
      border-top: 1px solid #F5F5F5;
      margin: 25px 0;
    }

    h1 {
      font-size: 28px;
      font-weight: bold;
      color: #FF4081;
    }
  </style>
</head>

<body>
  <?php
  echo '
    <nav class="navbar navbar-inverse">
    <div class="container-fluid">
      <div class="navbar-header">
        <a class="navbar-brand" href="#">Inventory Management</a>
      </div>
      <ul class="nav navbar-nav">
        <li><a href="../view/vendor_home.html">HOME</a></li>
        <li><a href="../view/add_item.php">ADD ITEM</a></li>
        <li><a href="../view/delete_items.php">DELETE ITEM</a></li>
        <li class="active"><a href="#">VIEW YOUR ITEMS</a></li>
        <li><a href="../view/view_orders.php">VIEW ORDERS</a></li>
        <li><a href="../view/vendor_login.php">LOG OUT</a></li>
      </ul>
    </div>
  </nav>
    <h1 style="text-align: center;color: darkorange;">LIST OF ITEMS</h1>
    <div class="row" style="padding: 40px;">
        <div class="leftcolumn">';
  ?>
  <?php
  session_start();
  $vend_id=$_SESSION["vendor_id"];
      $sql = "SELECT * FROM vendors WHERE vendor_id='$vend_id'";
      $result = mysqli_query($res, $sql); // fixed variable name
      if (mysqli_num_rows($result) === 1) {
        $row = mysqli_fetch_assoc($result);
          echo "<h3 style='text-align:center'>Logged in!</h3>";
          // removed the inline CSS and put it in a separate file
      
          // start the session and set the logged_in flag
          $_SESSION['logged_in'] = true;
  echo '<div class="card">
                <div class="table_container">
                    <div class="table-responsive">
                        <table class="table table-dark" id="table" data-toggle="table" data-search="true" data-filter-control="true" data-show-export="true" data-click-to-select="true" data-toolbar="#toolbar">
                            <thead class="thead-light">
                                <tr>
                                    <th data-field="date" data-filter-control="select" data-sortable="true">S.NO</th>
                                    <th data-field="note" data-filter-control="select" data-sortable="true">ITEM_NAME</th>
                                    <th data-field="examen" data-filter-control="select" data-sortable="true">ITEM_QUANTITY</th>
                                    <th data-field="note" data-sortable="true">PRICE</th>
                                </tr>
                            </thead>
                            <tbody>';
  $sql = "SELECT * FROM items where item_vendor='$vend_id'";
  $result = $res->query($sql);

    $i = 1;
    while ($row = $result->fetch_assoc()) {
      echo "<tr><td>" . $i++ . "</td><td>" . $row["item_name"] . "</td><td>" . $row["item_quantity"] . "</td><td>" . "₹" . $row["item_price"] . "</td></tr>";
    }
  echo '
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>';
}
else{
  $link_text="CREDENTIALS DIDNOT MATCHED. TRY AGAIN!!";
  $link_url="../view/item_view.php";
  echo '<script>alert("'.$link_text.'"); window.location="'.$link_url.'";</script>';
}
  ?>
  </div>
  <?php include('footer.php') ?>
</body>

</html>